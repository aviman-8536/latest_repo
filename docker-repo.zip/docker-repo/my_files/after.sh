docker pull santanurajbhar/docker-python-app:latest

docker run -p 8080:8080 -d santanurajbhar/docker-python-app:latest